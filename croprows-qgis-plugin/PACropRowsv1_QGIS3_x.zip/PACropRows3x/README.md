## Installation

Use the QGIS Plugins menu to install the Crop Rows Generator Plugin (see [QGIS manual](http://docs.qgis.org/latest/en/docs/user_manual/plugins/plugins.html) ).

## License

Crop Rows Generator Plugin is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

* <em>Copyright (c) 2018 Andres Herrera, Universidad del Valle</em>